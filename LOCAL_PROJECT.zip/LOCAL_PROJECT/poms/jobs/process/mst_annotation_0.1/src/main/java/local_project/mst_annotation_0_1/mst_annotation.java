// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package local_project.mst_annotation_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: mst_annotation Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class mst_annotation implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (mst_annotation_Header != null) {

				this.setProperty("mst_annotation_Header", mst_annotation_Header.toString());

			}

			if (mst_annotation_Encoding != null) {

				this.setProperty("mst_annotation_Encoding", mst_annotation_Encoding.toString());

			}

			if (mst_annotation_RowSeparator != null) {

				this.setProperty("mst_annotation_RowSeparator", mst_annotation_RowSeparator.toString());

			}

			if (mst_annotation_File != null) {

				this.setProperty("mst_annotation_File", mst_annotation_File.toString());

			}

			if (mst_annotation_FieldSeparator != null) {

				this.setProperty("mst_annotation_FieldSeparator", mst_annotation_FieldSeparator.toString());

			}

			if (annotation_Server != null) {

				this.setProperty("annotation_Server", annotation_Server.toString());

			}

			if (annotation_Password != null) {

				this.setProperty("annotation_Password", annotation_Password.toString());

			}

			if (annotation_Sid != null) {

				this.setProperty("annotation_Sid", annotation_Sid.toString());

			}

			if (annotation_Port != null) {

				this.setProperty("annotation_Port", annotation_Port.toString());

			}

			if (annotation_Schema != null) {

				this.setProperty("annotation_Schema", annotation_Schema.toString());

			}

			if (annotation_Login != null) {

				this.setProperty("annotation_Login", annotation_Login.toString());

			}

			if (annotation_AdditionalParams != null) {

				this.setProperty("annotation_AdditionalParams", annotation_AdditionalParams.toString());

			}

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

		public Integer mst_annotation_Header;

		public Integer getMst_annotation_Header() {
			return this.mst_annotation_Header;
		}

		public String mst_annotation_Encoding;

		public String getMst_annotation_Encoding() {
			return this.mst_annotation_Encoding;
		}

		public String mst_annotation_RowSeparator;

		public String getMst_annotation_RowSeparator() {
			return this.mst_annotation_RowSeparator;
		}

		public String mst_annotation_File;

		public String getMst_annotation_File() {
			return this.mst_annotation_File;
		}

		public String mst_annotation_FieldSeparator;

		public String getMst_annotation_FieldSeparator() {
			return this.mst_annotation_FieldSeparator;
		}

		public String annotation_Server;

		public String getAnnotation_Server() {
			return this.annotation_Server;
		}

		public java.lang.String annotation_Password;

		public java.lang.String getAnnotation_Password() {
			return this.annotation_Password;
		}

		public String annotation_Sid;

		public String getAnnotation_Sid() {
			return this.annotation_Sid;
		}

		public String annotation_Port;

		public String getAnnotation_Port() {
			return this.annotation_Port;
		}

		public String annotation_Schema;

		public String getAnnotation_Schema() {
			return this.annotation_Schema;
		}

		public String annotation_Login;

		public String getAnnotation_Login() {
			return this.annotation_Login;
		}

		public String annotation_AdditionalParams;

		public String getAnnotation_AdditionalParams() {
			return this.annotation_AdditionalParams;
		}
	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "mst_annotation";
	private final String projectName = "LOCAL_PROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					mst_annotation.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(mst_annotation.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class ErrorRejectStruct implements routines.system.IPersistableRow<ErrorRejectStruct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_mst_annotation = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[0];

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		public String errorStackTrace;

		public String getErrorStackTrace() {
			return this.errorStackTrace;
		}

		public String ID;

		public String getID() {
			return this.ID;
		}

		public String CHANGE_TIME;

		public String getCHANGE_TIME() {
			return this.CHANGE_TIME;
		}

		public String CREATED_BY;

		public String getCREATED_BY() {
			return this.CREATED_BY;
		}

		public String CREATION_TIME;

		public String getCREATION_TIME() {
			return this.CREATION_TIME;
		}

		public String ENABLED;

		public String getENABLED() {
			return this.ENABLED;
		}

		public String GUID;

		public String getGUID() {
			return this.GUID;
		}

		public String LAST_UPDATED_BY;

		public String getLAST_UPDATED_BY() {
			return this.LAST_UPDATED_BY;
		}

		public String OBJ_VERSION;

		public String getOBJ_VERSION() {
			return this.OBJ_VERSION;
		}

		public String STATUS;

		public String getSTATUS() {
			return this.STATUS;
		}

		public String ANNOTATION_TYPE;

		public String getANNOTATION_TYPE() {
			return this.ANNOTATION_TYPE;
		}

		public String REF_CLAIM;

		public String getREF_CLAIM() {
			return this.REF_CLAIM;
		}

		public String CONTENT_LENGTH;

		public String getCONTENT_LENGTH() {
			return this.CONTENT_LENGTH;
		}

		public String CONTENT_TYPE;

		public String getCONTENT_TYPE() {
			return this.CONTENT_TYPE;
		}

		public String DESCRIPTION;

		public String getDESCRIPTION() {
			return this.DESCRIPTION;
		}

		public String FILE_CLASSIFICATION;

		public String getFILE_CLASSIFICATION() {
			return this.FILE_CLASSIFICATION;
		}

		public String FILE_ID;

		public String getFILE_ID() {
			return this.FILE_ID;
		}

		public String FILE_NAME;

		public String getFILE_NAME() {
			return this.FILE_NAME;
		}

		public String OWNER;

		public String getOWNER() {
			return this.OWNER;
		}

		public String REFERENCE;

		public String getREFERENCE() {
			return this.REFERENCE;
		}

		public String ANN_VISIBILITY;

		public String getANN_VISIBILITY() {
			return this.ANN_VISIBILITY;
		}

		public String CLAIM_ID;

		public String getCLAIM_ID() {
			return this.CLAIM_ID;
		}

		public java.util.Date dt_chargement;

		public java.util.Date getDt_chargement() {
			return this.dt_chargement;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					this.errorMessage = readString(dis);

					this.errorStackTrace = readString(dis);

					this.ID = readString(dis);

					this.CHANGE_TIME = readString(dis);

					this.CREATED_BY = readString(dis);

					this.CREATION_TIME = readString(dis);

					this.ENABLED = readString(dis);

					this.GUID = readString(dis);

					this.LAST_UPDATED_BY = readString(dis);

					this.OBJ_VERSION = readString(dis);

					this.STATUS = readString(dis);

					this.ANNOTATION_TYPE = readString(dis);

					this.REF_CLAIM = readString(dis);

					this.CONTENT_LENGTH = readString(dis);

					this.CONTENT_TYPE = readString(dis);

					this.DESCRIPTION = readString(dis);

					this.FILE_CLASSIFICATION = readString(dis);

					this.FILE_ID = readString(dis);

					this.FILE_NAME = readString(dis);

					this.OWNER = readString(dis);

					this.REFERENCE = readString(dis);

					this.ANN_VISIBILITY = readString(dis);

					this.CLAIM_ID = readString(dis);

					this.dt_chargement = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					this.errorMessage = readString(dis);

					this.errorStackTrace = readString(dis);

					this.ID = readString(dis);

					this.CHANGE_TIME = readString(dis);

					this.CREATED_BY = readString(dis);

					this.CREATION_TIME = readString(dis);

					this.ENABLED = readString(dis);

					this.GUID = readString(dis);

					this.LAST_UPDATED_BY = readString(dis);

					this.OBJ_VERSION = readString(dis);

					this.STATUS = readString(dis);

					this.ANNOTATION_TYPE = readString(dis);

					this.REF_CLAIM = readString(dis);

					this.CONTENT_LENGTH = readString(dis);

					this.CONTENT_TYPE = readString(dis);

					this.DESCRIPTION = readString(dis);

					this.FILE_CLASSIFICATION = readString(dis);

					this.FILE_ID = readString(dis);

					this.FILE_NAME = readString(dis);

					this.OWNER = readString(dis);

					this.REFERENCE = readString(dis);

					this.ANN_VISIBILITY = readString(dis);

					this.CLAIM_ID = readString(dis);

					this.dt_chargement = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.errorMessage, dos);

				// String

				writeString(this.errorStackTrace, dos);

				// String

				writeString(this.ID, dos);

				// String

				writeString(this.CHANGE_TIME, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// String

				writeString(this.CREATION_TIME, dos);

				// String

				writeString(this.ENABLED, dos);

				// String

				writeString(this.GUID, dos);

				// String

				writeString(this.LAST_UPDATED_BY, dos);

				// String

				writeString(this.OBJ_VERSION, dos);

				// String

				writeString(this.STATUS, dos);

				// String

				writeString(this.ANNOTATION_TYPE, dos);

				// String

				writeString(this.REF_CLAIM, dos);

				// String

				writeString(this.CONTENT_LENGTH, dos);

				// String

				writeString(this.CONTENT_TYPE, dos);

				// String

				writeString(this.DESCRIPTION, dos);

				// String

				writeString(this.FILE_CLASSIFICATION, dos);

				// String

				writeString(this.FILE_ID, dos);

				// String

				writeString(this.FILE_NAME, dos);

				// String

				writeString(this.OWNER, dos);

				// String

				writeString(this.REFERENCE, dos);

				// String

				writeString(this.ANN_VISIBILITY, dos);

				// String

				writeString(this.CLAIM_ID, dos);

				// java.util.Date

				writeDate(this.dt_chargement, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.errorMessage, dos);

				// String

				writeString(this.errorStackTrace, dos);

				// String

				writeString(this.ID, dos);

				// String

				writeString(this.CHANGE_TIME, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// String

				writeString(this.CREATION_TIME, dos);

				// String

				writeString(this.ENABLED, dos);

				// String

				writeString(this.GUID, dos);

				// String

				writeString(this.LAST_UPDATED_BY, dos);

				// String

				writeString(this.OBJ_VERSION, dos);

				// String

				writeString(this.STATUS, dos);

				// String

				writeString(this.ANNOTATION_TYPE, dos);

				// String

				writeString(this.REF_CLAIM, dos);

				// String

				writeString(this.CONTENT_LENGTH, dos);

				// String

				writeString(this.CONTENT_TYPE, dos);

				// String

				writeString(this.DESCRIPTION, dos);

				// String

				writeString(this.FILE_CLASSIFICATION, dos);

				// String

				writeString(this.FILE_ID, dos);

				// String

				writeString(this.FILE_NAME, dos);

				// String

				writeString(this.OWNER, dos);

				// String

				writeString(this.REFERENCE, dos);

				// String

				writeString(this.ANN_VISIBILITY, dos);

				// String

				writeString(this.CLAIM_ID, dos);

				// java.util.Date

				writeDate(this.dt_chargement, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("errorMessage=" + errorMessage);
			sb.append(",errorStackTrace=" + errorStackTrace);
			sb.append(",ID=" + ID);
			sb.append(",CHANGE_TIME=" + CHANGE_TIME);
			sb.append(",CREATED_BY=" + CREATED_BY);
			sb.append(",CREATION_TIME=" + CREATION_TIME);
			sb.append(",ENABLED=" + ENABLED);
			sb.append(",GUID=" + GUID);
			sb.append(",LAST_UPDATED_BY=" + LAST_UPDATED_BY);
			sb.append(",OBJ_VERSION=" + OBJ_VERSION);
			sb.append(",STATUS=" + STATUS);
			sb.append(",ANNOTATION_TYPE=" + ANNOTATION_TYPE);
			sb.append(",REF_CLAIM=" + REF_CLAIM);
			sb.append(",CONTENT_LENGTH=" + CONTENT_LENGTH);
			sb.append(",CONTENT_TYPE=" + CONTENT_TYPE);
			sb.append(",DESCRIPTION=" + DESCRIPTION);
			sb.append(",FILE_CLASSIFICATION=" + FILE_CLASSIFICATION);
			sb.append(",FILE_ID=" + FILE_ID);
			sb.append(",FILE_NAME=" + FILE_NAME);
			sb.append(",OWNER=" + OWNER);
			sb.append(",REFERENCE=" + REFERENCE);
			sb.append(",ANN_VISIBILITY=" + ANN_VISIBILITY);
			sb.append(",CLAIM_ID=" + CLAIM_ID);
			sb.append(",dt_chargement=" + String.valueOf(dt_chargement));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(ErrorRejectStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class mst_annotationStruct implements routines.system.IPersistableRow<mst_annotationStruct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_mst_annotation = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[0];

		public Long id;

		public Long getId() {
			return this.id;
		}

		public java.util.Date change_time;

		public java.util.Date getChange_time() {
			return this.change_time;
		}

		public String CREATED_BY;

		public String getCREATED_BY() {
			return this.CREATED_BY;
		}

		public java.util.Date creation_time;

		public java.util.Date getCreation_time() {
			return this.creation_time;
		}

		public String enabled;

		public String getEnabled() {
			return this.enabled;
		}

		public String guid;

		public String getGuid() {
			return this.guid;
		}

		public String last_updated_by;

		public String getLast_updated_by() {
			return this.last_updated_by;
		}

		public Long obj_version;

		public Long getObj_version() {
			return this.obj_version;
		}

		public String status;

		public String getStatus() {
			return this.status;
		}

		public String annotation_type;

		public String getAnnotation_type() {
			return this.annotation_type;
		}

		public String ref_claim;

		public String getRef_claim() {
			return this.ref_claim;
		}

		public Long content_length;

		public Long getContent_length() {
			return this.content_length;
		}

		public String content_type;

		public String getContent_type() {
			return this.content_type;
		}

		public String description;

		public String getDescription() {
			return this.description;
		}

		public String fileclassification;

		public String getFileclassification() {
			return this.fileclassification;
		}

		public String file_id;

		public String getFile_id() {
			return this.file_id;
		}

		public String file_name;

		public String getFile_name() {
			return this.file_name;
		}

		public String owner;

		public String getOwner() {
			return this.owner;
		}

		public String reference;

		public String getReference() {
			return this.reference;
		}

		public String ann_visibility;

		public String getAnn_visibility() {
			return this.ann_visibility;
		}

		public Long claim_id;

		public Long getClaim_id() {
			return this.claim_id;
		}

		public java.util.Date dt_chargement;

		public java.util.Date getDt_chargement() {
			return this.dt_chargement;
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.id = null;
					} else {
						this.id = dis.readLong();
					}

					this.change_time = readDate(dis);

					this.CREATED_BY = readString(dis);

					this.creation_time = readDate(dis);

					this.enabled = readString(dis);

					this.guid = readString(dis);

					this.last_updated_by = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.obj_version = null;
					} else {
						this.obj_version = dis.readLong();
					}

					this.status = readString(dis);

					this.annotation_type = readString(dis);

					this.ref_claim = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.content_length = null;
					} else {
						this.content_length = dis.readLong();
					}

					this.content_type = readString(dis);

					this.description = readString(dis);

					this.fileclassification = readString(dis);

					this.file_id = readString(dis);

					this.file_name = readString(dis);

					this.owner = readString(dis);

					this.reference = readString(dis);

					this.ann_visibility = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.claim_id = null;
					} else {
						this.claim_id = dis.readLong();
					}

					this.dt_chargement = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.id = null;
					} else {
						this.id = dis.readLong();
					}

					this.change_time = readDate(dis);

					this.CREATED_BY = readString(dis);

					this.creation_time = readDate(dis);

					this.enabled = readString(dis);

					this.guid = readString(dis);

					this.last_updated_by = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.obj_version = null;
					} else {
						this.obj_version = dis.readLong();
					}

					this.status = readString(dis);

					this.annotation_type = readString(dis);

					this.ref_claim = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.content_length = null;
					} else {
						this.content_length = dis.readLong();
					}

					this.content_type = readString(dis);

					this.description = readString(dis);

					this.fileclassification = readString(dis);

					this.file_id = readString(dis);

					this.file_name = readString(dis);

					this.owner = readString(dis);

					this.reference = readString(dis);

					this.ann_visibility = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.claim_id = null;
					} else {
						this.claim_id = dis.readLong();
					}

					this.dt_chargement = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// Long

				if (this.id == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.id);
				}

				// java.util.Date

				writeDate(this.change_time, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// java.util.Date

				writeDate(this.creation_time, dos);

				// String

				writeString(this.enabled, dos);

				// String

				writeString(this.guid, dos);

				// String

				writeString(this.last_updated_by, dos);

				// Long

				if (this.obj_version == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.obj_version);
				}

				// String

				writeString(this.status, dos);

				// String

				writeString(this.annotation_type, dos);

				// String

				writeString(this.ref_claim, dos);

				// Long

				if (this.content_length == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.content_length);
				}

				// String

				writeString(this.content_type, dos);

				// String

				writeString(this.description, dos);

				// String

				writeString(this.fileclassification, dos);

				// String

				writeString(this.file_id, dos);

				// String

				writeString(this.file_name, dos);

				// String

				writeString(this.owner, dos);

				// String

				writeString(this.reference, dos);

				// String

				writeString(this.ann_visibility, dos);

				// Long

				if (this.claim_id == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.claim_id);
				}

				// java.util.Date

				writeDate(this.dt_chargement, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Long

				if (this.id == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.id);
				}

				// java.util.Date

				writeDate(this.change_time, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// java.util.Date

				writeDate(this.creation_time, dos);

				// String

				writeString(this.enabled, dos);

				// String

				writeString(this.guid, dos);

				// String

				writeString(this.last_updated_by, dos);

				// Long

				if (this.obj_version == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.obj_version);
				}

				// String

				writeString(this.status, dos);

				// String

				writeString(this.annotation_type, dos);

				// String

				writeString(this.ref_claim, dos);

				// Long

				if (this.content_length == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.content_length);
				}

				// String

				writeString(this.content_type, dos);

				// String

				writeString(this.description, dos);

				// String

				writeString(this.fileclassification, dos);

				// String

				writeString(this.file_id, dos);

				// String

				writeString(this.file_name, dos);

				// String

				writeString(this.owner, dos);

				// String

				writeString(this.reference, dos);

				// String

				writeString(this.ann_visibility, dos);

				// Long

				if (this.claim_id == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.claim_id);
				}

				// java.util.Date

				writeDate(this.dt_chargement, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("id=" + String.valueOf(id));
			sb.append(",change_time=" + String.valueOf(change_time));
			sb.append(",CREATED_BY=" + CREATED_BY);
			sb.append(",creation_time=" + String.valueOf(creation_time));
			sb.append(",enabled=" + enabled);
			sb.append(",guid=" + guid);
			sb.append(",last_updated_by=" + last_updated_by);
			sb.append(",obj_version=" + String.valueOf(obj_version));
			sb.append(",status=" + status);
			sb.append(",annotation_type=" + annotation_type);
			sb.append(",ref_claim=" + ref_claim);
			sb.append(",content_length=" + String.valueOf(content_length));
			sb.append(",content_type=" + content_type);
			sb.append(",description=" + description);
			sb.append(",fileclassification=" + fileclassification);
			sb.append(",file_id=" + file_id);
			sb.append(",file_name=" + file_name);
			sb.append(",owner=" + owner);
			sb.append(",reference=" + reference);
			sb.append(",ann_visibility=" + ann_visibility);
			sb.append(",claim_id=" + String.valueOf(claim_id));
			sb.append(",dt_chargement=" + String.valueOf(dt_chargement));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(mst_annotationStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_LOCAL_PROJECT_mst_annotation = new byte[0];
		static byte[] commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[0];

		public String ID;

		public String getID() {
			return this.ID;
		}

		public String CHANGE_TIME;

		public String getCHANGE_TIME() {
			return this.CHANGE_TIME;
		}

		public String CREATED_BY;

		public String getCREATED_BY() {
			return this.CREATED_BY;
		}

		public String CREATION_TIME;

		public String getCREATION_TIME() {
			return this.CREATION_TIME;
		}

		public String ENABLED;

		public String getENABLED() {
			return this.ENABLED;
		}

		public String GUID;

		public String getGUID() {
			return this.GUID;
		}

		public String LAST_UPDATED_BY;

		public String getLAST_UPDATED_BY() {
			return this.LAST_UPDATED_BY;
		}

		public String OBJ_VERSION;

		public String getOBJ_VERSION() {
			return this.OBJ_VERSION;
		}

		public String STATUS;

		public String getSTATUS() {
			return this.STATUS;
		}

		public String ANNOTATION_TYPE;

		public String getANNOTATION_TYPE() {
			return this.ANNOTATION_TYPE;
		}

		public String REF_CLAIM;

		public String getREF_CLAIM() {
			return this.REF_CLAIM;
		}

		public String CONTENT_LENGTH;

		public String getCONTENT_LENGTH() {
			return this.CONTENT_LENGTH;
		}

		public String CONTENT_TYPE;

		public String getCONTENT_TYPE() {
			return this.CONTENT_TYPE;
		}

		public String DESCRIPTION;

		public String getDESCRIPTION() {
			return this.DESCRIPTION;
		}

		public String FILE_CLASSIFICATION;

		public String getFILE_CLASSIFICATION() {
			return this.FILE_CLASSIFICATION;
		}

		public String FILE_ID;

		public String getFILE_ID() {
			return this.FILE_ID;
		}

		public String FILE_NAME;

		public String getFILE_NAME() {
			return this.FILE_NAME;
		}

		public String OWNER;

		public String getOWNER() {
			return this.OWNER;
		}

		public String REFERENCE;

		public String getREFERENCE() {
			return this.REFERENCE;
		}

		public String ANN_VISIBILITY;

		public String getANN_VISIBILITY() {
			return this.ANN_VISIBILITY;
		}

		public String CLAIM_ID;

		public String getCLAIM_ID() {
			return this.CLAIM_ID;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_LOCAL_PROJECT_mst_annotation.length) {
					if (length < 1024 && commonByteArray_LOCAL_PROJECT_mst_annotation.length == 0) {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[1024];
					} else {
						commonByteArray_LOCAL_PROJECT_mst_annotation = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length);
				strReturn = new String(commonByteArray_LOCAL_PROJECT_mst_annotation, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					this.ID = readString(dis);

					this.CHANGE_TIME = readString(dis);

					this.CREATED_BY = readString(dis);

					this.CREATION_TIME = readString(dis);

					this.ENABLED = readString(dis);

					this.GUID = readString(dis);

					this.LAST_UPDATED_BY = readString(dis);

					this.OBJ_VERSION = readString(dis);

					this.STATUS = readString(dis);

					this.ANNOTATION_TYPE = readString(dis);

					this.REF_CLAIM = readString(dis);

					this.CONTENT_LENGTH = readString(dis);

					this.CONTENT_TYPE = readString(dis);

					this.DESCRIPTION = readString(dis);

					this.FILE_CLASSIFICATION = readString(dis);

					this.FILE_ID = readString(dis);

					this.FILE_NAME = readString(dis);

					this.OWNER = readString(dis);

					this.REFERENCE = readString(dis);

					this.ANN_VISIBILITY = readString(dis);

					this.CLAIM_ID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_LOCAL_PROJECT_mst_annotation) {

				try {

					int length = 0;

					this.ID = readString(dis);

					this.CHANGE_TIME = readString(dis);

					this.CREATED_BY = readString(dis);

					this.CREATION_TIME = readString(dis);

					this.ENABLED = readString(dis);

					this.GUID = readString(dis);

					this.LAST_UPDATED_BY = readString(dis);

					this.OBJ_VERSION = readString(dis);

					this.STATUS = readString(dis);

					this.ANNOTATION_TYPE = readString(dis);

					this.REF_CLAIM = readString(dis);

					this.CONTENT_LENGTH = readString(dis);

					this.CONTENT_TYPE = readString(dis);

					this.DESCRIPTION = readString(dis);

					this.FILE_CLASSIFICATION = readString(dis);

					this.FILE_ID = readString(dis);

					this.FILE_NAME = readString(dis);

					this.OWNER = readString(dis);

					this.REFERENCE = readString(dis);

					this.ANN_VISIBILITY = readString(dis);

					this.CLAIM_ID = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.ID, dos);

				// String

				writeString(this.CHANGE_TIME, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// String

				writeString(this.CREATION_TIME, dos);

				// String

				writeString(this.ENABLED, dos);

				// String

				writeString(this.GUID, dos);

				// String

				writeString(this.LAST_UPDATED_BY, dos);

				// String

				writeString(this.OBJ_VERSION, dos);

				// String

				writeString(this.STATUS, dos);

				// String

				writeString(this.ANNOTATION_TYPE, dos);

				// String

				writeString(this.REF_CLAIM, dos);

				// String

				writeString(this.CONTENT_LENGTH, dos);

				// String

				writeString(this.CONTENT_TYPE, dos);

				// String

				writeString(this.DESCRIPTION, dos);

				// String

				writeString(this.FILE_CLASSIFICATION, dos);

				// String

				writeString(this.FILE_ID, dos);

				// String

				writeString(this.FILE_NAME, dos);

				// String

				writeString(this.OWNER, dos);

				// String

				writeString(this.REFERENCE, dos);

				// String

				writeString(this.ANN_VISIBILITY, dos);

				// String

				writeString(this.CLAIM_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.ID, dos);

				// String

				writeString(this.CHANGE_TIME, dos);

				// String

				writeString(this.CREATED_BY, dos);

				// String

				writeString(this.CREATION_TIME, dos);

				// String

				writeString(this.ENABLED, dos);

				// String

				writeString(this.GUID, dos);

				// String

				writeString(this.LAST_UPDATED_BY, dos);

				// String

				writeString(this.OBJ_VERSION, dos);

				// String

				writeString(this.STATUS, dos);

				// String

				writeString(this.ANNOTATION_TYPE, dos);

				// String

				writeString(this.REF_CLAIM, dos);

				// String

				writeString(this.CONTENT_LENGTH, dos);

				// String

				writeString(this.CONTENT_TYPE, dos);

				// String

				writeString(this.DESCRIPTION, dos);

				// String

				writeString(this.FILE_CLASSIFICATION, dos);

				// String

				writeString(this.FILE_ID, dos);

				// String

				writeString(this.FILE_NAME, dos);

				// String

				writeString(this.OWNER, dos);

				// String

				writeString(this.REFERENCE, dos);

				// String

				writeString(this.ANN_VISIBILITY, dos);

				// String

				writeString(this.CLAIM_ID, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("ID=" + ID);
			sb.append(",CHANGE_TIME=" + CHANGE_TIME);
			sb.append(",CREATED_BY=" + CREATED_BY);
			sb.append(",CREATION_TIME=" + CREATION_TIME);
			sb.append(",ENABLED=" + ENABLED);
			sb.append(",GUID=" + GUID);
			sb.append(",LAST_UPDATED_BY=" + LAST_UPDATED_BY);
			sb.append(",OBJ_VERSION=" + OBJ_VERSION);
			sb.append(",STATUS=" + STATUS);
			sb.append(",ANNOTATION_TYPE=" + ANNOTATION_TYPE);
			sb.append(",REF_CLAIM=" + REF_CLAIM);
			sb.append(",CONTENT_LENGTH=" + CONTENT_LENGTH);
			sb.append(",CONTENT_TYPE=" + CONTENT_TYPE);
			sb.append(",DESCRIPTION=" + DESCRIPTION);
			sb.append(",FILE_CLASSIFICATION=" + FILE_CLASSIFICATION);
			sb.append(",FILE_ID=" + FILE_ID);
			sb.append(",FILE_NAME=" + FILE_NAME);
			sb.append(",OWNER=" + OWNER);
			sb.append(",REFERENCE=" + REFERENCE);
			sb.append(",ANN_VISIBILITY=" + ANN_VISIBILITY);
			sb.append(",CLAIM_ID=" + CLAIM_ID);
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				ErrorRejectStruct ErrorReject = new ErrorRejectStruct();
				mst_annotationStruct mst_annotation = new mst_annotationStruct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "ErrorReject");
				}

				int tos_count_tDBOutput_1 = 0;

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int tmp_batchUpdateCount_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				boolean whetherReject_tDBOutput_1 = false;

				java.sql.Connection conn_tDBOutput_1 = null;

				// optional table
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				String driverClass_tDBOutput_1 = "oracle.jdbc.OracleDriver";

				java.lang.Class.forName(driverClass_tDBOutput_1);
				String url_tDBOutput_1 = null;
				url_tDBOutput_1 = "jdbc:oracle:thin:@" + context.annotation_Server + ":" + context.annotation_Port + ":"
						+ context.annotation_Sid;
				String dbUser_tDBOutput_1 = context.annotation_Login;

				final String decryptedPassword_tDBOutput_1 = context.annotation_Password;

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				dbschema_tDBOutput_1 = context.annotation_Schema;

				java.util.Properties atnParamsPrope_tDBOutput_1 = new java.util.Properties();
				atnParamsPrope_tDBOutput_1.put("user", dbUser_tDBOutput_1);
				atnParamsPrope_tDBOutput_1.put("password", dbPwd_tDBOutput_1);
				if (context.annotation_AdditionalParams != null && !"\"\"".equals(context.annotation_AdditionalParams)
						&& !"".equals(context.annotation_AdditionalParams)) {
					atnParamsPrope_tDBOutput_1.load(new java.io.ByteArrayInputStream(
							context.annotation_AdditionalParams.replace("&", "\n").getBytes()));
				}
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, atnParamsPrope_tDBOutput_1);
				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;
				int batchSize_tDBOutput_1 = 10000;
				int batchSizeCounter_tDBOutput_1 = 0;
				int count_tDBOutput_1 = 0;

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = ("ST_ANNOTATION_RJT");
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "." + ("ST_ANNOTATION_RJT");
				}
				int rsTruncCountNumber_tDBOutput_1 = 0;
				try (java.sql.Statement stmtTruncCount_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					try (java.sql.ResultSet rsTruncCount_tDBOutput_1 = stmtTruncCount_tDBOutput_1
							.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_1 + "")) {
						if (rsTruncCount_tDBOutput_1.next()) {
							rsTruncCountNumber_tDBOutput_1 = rsTruncCount_tDBOutput_1.getInt(1);
						}
					}
				}
				try (java.sql.Statement stmtTrunc_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					stmtTrunc_tDBOutput_1.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_1 + "");
					deletedCount_tDBOutput_1 += rsTruncCountNumber_tDBOutput_1;
				}
				String insert_tDBOutput_1 = "INSERT INTO " + tableName_tDBOutput_1
						+ " (errorMessage,errorStackTrace,ID,CHANGE_TIME,CREATED_BY,CREATION_TIME,ENABLED,GUID,LAST_UPDATED_BY,OBJ_VERSION,STATUS,ANNOTATION_TYPE,REF_CLAIM,CONTENT_LENGTH,CONTENT_TYPE,DESCRIPTION,FILE_CLASSIFICATION,FILE_ID,FILE_NAME,OWNER,REFERENCE,ANN_VISIBILITY,CLAIM_ID,dt_chargement) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tDBOutput_2 begin ] start
				 */

				ok_Hash.put("tDBOutput_2", false);
				start_Hash.put("tDBOutput_2", System.currentTimeMillis());

				currentComponent = "tDBOutput_2";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "mst_annotation");
				}

				int tos_count_tDBOutput_2 = 0;

				int nb_line_tDBOutput_2 = 0;
				int nb_line_update_tDBOutput_2 = 0;
				int nb_line_inserted_tDBOutput_2 = 0;
				int nb_line_deleted_tDBOutput_2 = 0;
				int nb_line_rejected_tDBOutput_2 = 0;

				int tmp_batchUpdateCount_tDBOutput_2 = 0;

				int deletedCount_tDBOutput_2 = 0;
				int updatedCount_tDBOutput_2 = 0;
				int insertedCount_tDBOutput_2 = 0;
				int rowsToCommitCount_tDBOutput_2 = 0;
				int rejectedCount_tDBOutput_2 = 0;

				boolean whetherReject_tDBOutput_2 = false;

				java.sql.Connection conn_tDBOutput_2 = null;

				// optional table
				String dbschema_tDBOutput_2 = null;
				String tableName_tDBOutput_2 = null;
				String driverClass_tDBOutput_2 = "oracle.jdbc.OracleDriver";

				java.lang.Class.forName(driverClass_tDBOutput_2);
				String url_tDBOutput_2 = null;
				url_tDBOutput_2 = "jdbc:oracle:thin:@" + context.annotation_Server + ":" + context.annotation_Port + ":"
						+ context.annotation_Sid;
				String dbUser_tDBOutput_2 = context.annotation_Login;

				final String decryptedPassword_tDBOutput_2 = context.annotation_Password;

				String dbPwd_tDBOutput_2 = decryptedPassword_tDBOutput_2;
				dbschema_tDBOutput_2 = context.annotation_Schema;

				java.util.Properties atnParamsPrope_tDBOutput_2 = new java.util.Properties();
				atnParamsPrope_tDBOutput_2.put("user", dbUser_tDBOutput_2);
				atnParamsPrope_tDBOutput_2.put("password", dbPwd_tDBOutput_2);
				if (context.annotation_AdditionalParams != null && !"\"\"".equals(context.annotation_AdditionalParams)
						&& !"".equals(context.annotation_AdditionalParams)) {
					atnParamsPrope_tDBOutput_2.load(new java.io.ByteArrayInputStream(
							context.annotation_AdditionalParams.replace("&", "\n").getBytes()));
				}
				conn_tDBOutput_2 = java.sql.DriverManager.getConnection(url_tDBOutput_2, atnParamsPrope_tDBOutput_2);
				resourceMap.put("conn_tDBOutput_2", conn_tDBOutput_2);
				conn_tDBOutput_2.setAutoCommit(false);
				int commitEvery_tDBOutput_2 = 10000;
				int commitCounter_tDBOutput_2 = 0;
				int batchSize_tDBOutput_2 = 10000;
				int batchSizeCounter_tDBOutput_2 = 0;
				int count_tDBOutput_2 = 0;

				if (dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
					tableName_tDBOutput_2 = ("ST_ANNOTATION");
				} else {
					tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "." + ("ST_ANNOTATION");
				}
				int rsTruncCountNumber_tDBOutput_2 = 0;
				try (java.sql.Statement stmtTruncCount_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
					try (java.sql.ResultSet rsTruncCount_tDBOutput_2 = stmtTruncCount_tDBOutput_2
							.executeQuery("SELECT COUNT(1) FROM " + tableName_tDBOutput_2 + "")) {
						if (rsTruncCount_tDBOutput_2.next()) {
							rsTruncCountNumber_tDBOutput_2 = rsTruncCount_tDBOutput_2.getInt(1);
						}
					}
				}
				try (java.sql.Statement stmtTrunc_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
					stmtTrunc_tDBOutput_2.executeUpdate("TRUNCATE TABLE " + tableName_tDBOutput_2 + "");
					deletedCount_tDBOutput_2 += rsTruncCountNumber_tDBOutput_2;
				}
				String insert_tDBOutput_2 = "INSERT INTO " + tableName_tDBOutput_2
						+ " (id,change_time,CREATED_BY,creation_time,enabled,guid,last_updated_by,obj_version,status,annotation_type,ref_claim,content_length,content_type,description,fileclassification,file_id,file_name,owner,reference,ann_visibility,claim_id,dt_chargement) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

				java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
				resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);

				/**
				 * [tDBOutput_2 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "row1");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				ErrorRejectStruct ErrorReject_tmp = new ErrorRejectStruct();
				mst_annotationStruct mst_annotation_tmp = new mst_annotationStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try {

					Object filename_tFileInputDelimited_2 = "C:/Users/Yassine Bahaj/Desktop/pfa/Files_CSV_200723/ods_annotation.csv";
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0 || random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Yassine Bahaj/Desktop/pfa/Files_CSV_200723/ods_annotation.csv", "UTF-8", "|",
								"\n", false, 1, 0, limit_tFileInputDelimited_2, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_2 != null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();

						row1 = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						row1 = new row1Struct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							columnIndexWithD_tFileInputDelimited_2 = 0;

							row1.ID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 1;

							row1.CHANGE_TIME = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 2;

							row1.CREATED_BY = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 3;

							row1.CREATION_TIME = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 4;

							row1.ENABLED = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 5;

							row1.GUID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 6;

							row1.LAST_UPDATED_BY = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 7;

							row1.OBJ_VERSION = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 8;

							row1.STATUS = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 9;

							row1.ANNOTATION_TYPE = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 10;

							row1.REF_CLAIM = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 11;

							row1.CONTENT_LENGTH = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 12;

							row1.CONTENT_TYPE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 13;

							row1.DESCRIPTION = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 14;

							row1.FILE_CLASSIFICATION = fid_tFileInputDelimited_2
									.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 15;

							row1.FILE_ID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 16;

							row1.FILE_NAME = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 17;

							row1.OWNER = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 18;

							row1.REFERENCE = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 19;

							row1.ANN_VISIBILITY = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 20;

							row1.CLAIM_ID = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							System.err.println(e.getMessage());
							row1 = null;

						}

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "row1"
						if (row1 != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "row1"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							try {
								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_1 = false;
								boolean mainRowRejected_tMap_1 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
									// ###############################
									// # Output tables

									ErrorReject = null;
									mst_annotation = null;

// # Output table : 'mst_annotation'
									mst_annotation_tmp.id = Long.parseLong(row1.ID);
									mst_annotation_tmp.change_time = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss",
											row1.CHANGE_TIME);
									mst_annotation_tmp.CREATED_BY = row1.CREATED_BY;
									mst_annotation_tmp.creation_time = TalendDate.parseDate("yyyy-MM-dd",
											row1.CREATION_TIME);
									mst_annotation_tmp.enabled = row1.ENABLED;
									mst_annotation_tmp.guid = row1.GUID;
									mst_annotation_tmp.last_updated_by = row1.LAST_UPDATED_BY;
									mst_annotation_tmp.obj_version = Long.parseLong(row1.OBJ_VERSION);
									mst_annotation_tmp.status = row1.STATUS;
									mst_annotation_tmp.annotation_type = row1.ANNOTATION_TYPE;
									mst_annotation_tmp.ref_claim = row1.REF_CLAIM;
									mst_annotation_tmp.content_length = Long.parseLong(row1.CONTENT_LENGTH);
									mst_annotation_tmp.content_type = row1.CONTENT_TYPE;
									mst_annotation_tmp.description = row1.DESCRIPTION;
									mst_annotation_tmp.fileclassification = row1.FILE_CLASSIFICATION;
									mst_annotation_tmp.file_id = row1.FILE_ID;
									mst_annotation_tmp.file_name = row1.FILE_NAME;
									mst_annotation_tmp.owner = row1.OWNER;
									mst_annotation_tmp.reference = row1.REFERENCE;
									mst_annotation_tmp.ann_visibility = row1.ANN_VISIBILITY;
									mst_annotation_tmp.claim_id = Long.parseLong(row1.ANN_VISIBILITY);
									mst_annotation_tmp.dt_chargement = TalendDate.getCurrentDate();
									mst_annotation = mst_annotation_tmp;
// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_1 = false;

							} catch (java.lang.Exception e) {
								// if anohter java.lang.Exception when processing an java.lang.Exception

								try {// EE
									Var__tMap_1__Struct Var = Var__tMap_1;

									ErrorReject_tmp.ID = row1.ID;
									ErrorReject_tmp.CHANGE_TIME = row1.CHANGE_TIME;
									ErrorReject_tmp.CREATED_BY = row1.CREATED_BY;
									ErrorReject_tmp.CREATION_TIME = row1.CREATION_TIME;
									ErrorReject_tmp.ENABLED = row1.ENABLED;
									ErrorReject_tmp.GUID = row1.GUID;
									ErrorReject_tmp.LAST_UPDATED_BY = row1.LAST_UPDATED_BY;
									ErrorReject_tmp.OBJ_VERSION = row1.OBJ_VERSION;
									ErrorReject_tmp.STATUS = row1.STATUS;
									ErrorReject_tmp.ANNOTATION_TYPE = row1.ANNOTATION_TYPE;
									ErrorReject_tmp.REF_CLAIM = row1.REF_CLAIM;
									ErrorReject_tmp.CONTENT_LENGTH = row1.CONTENT_LENGTH;
									ErrorReject_tmp.CONTENT_TYPE = row1.CONTENT_TYPE;
									ErrorReject_tmp.DESCRIPTION = row1.DESCRIPTION;
									ErrorReject_tmp.FILE_CLASSIFICATION = row1.FILE_CLASSIFICATION;
									ErrorReject_tmp.FILE_ID = row1.FILE_ID;
									ErrorReject_tmp.FILE_NAME = row1.FILE_NAME;
									ErrorReject_tmp.OWNER = row1.OWNER;
									ErrorReject_tmp.REFERENCE = row1.REFERENCE;
									ErrorReject_tmp.ANN_VISIBILITY = row1.ANN_VISIBILITY;
									ErrorReject_tmp.CLAIM_ID = row1.CLAIM_ID;
									ErrorReject_tmp.dt_chargement = TalendDate.getCurrentDate();
									ErrorReject = ErrorReject_tmp;
									ErrorReject.errorMessage = e.getMessage();
									ErrorReject.errorStackTrace = ResumeUtil.getExceptionStackTrace(e);

									mst_annotation = null;
								} catch (java.lang.Exception ee) {// EE

									ee.printStackTrace();
									mst_annotation = null;
								} // EE
							} // end catch

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "ErrorReject"
							if (ErrorReject != null) {

								/**
								 * [tDBOutput_1 main ] start
								 */

								currentComponent = "tDBOutput_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "ErrorReject"

									);
								}

								whetherReject_tDBOutput_1 = false;
								if (ErrorReject.errorMessage == null) {
									pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(1, ErrorReject.errorMessage);
								}

								if (ErrorReject.errorStackTrace == null) {
									pstmt_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(2, ErrorReject.errorStackTrace);
								}

								if (ErrorReject.ID == null) {
									pstmt_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(3, ErrorReject.ID);
								}

								if (ErrorReject.CHANGE_TIME == null) {
									pstmt_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(4, ErrorReject.CHANGE_TIME);
								}

								if (ErrorReject.CREATED_BY == null) {
									pstmt_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(5, ErrorReject.CREATED_BY);
								}

								if (ErrorReject.CREATION_TIME == null) {
									pstmt_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(6, ErrorReject.CREATION_TIME);
								}

								if (ErrorReject.ENABLED == null) {
									pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(7, ErrorReject.ENABLED);
								}

								if (ErrorReject.GUID == null) {
									pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(8, ErrorReject.GUID);
								}

								if (ErrorReject.LAST_UPDATED_BY == null) {
									pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(9, ErrorReject.LAST_UPDATED_BY);
								}

								if (ErrorReject.OBJ_VERSION == null) {
									pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(10, ErrorReject.OBJ_VERSION);
								}

								if (ErrorReject.STATUS == null) {
									pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(11, ErrorReject.STATUS);
								}

								if (ErrorReject.ANNOTATION_TYPE == null) {
									pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(12, ErrorReject.ANNOTATION_TYPE);
								}

								if (ErrorReject.REF_CLAIM == null) {
									pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(13, ErrorReject.REF_CLAIM);
								}

								if (ErrorReject.CONTENT_LENGTH == null) {
									pstmt_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(14, ErrorReject.CONTENT_LENGTH);
								}

								if (ErrorReject.CONTENT_TYPE == null) {
									pstmt_tDBOutput_1.setNull(15, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(15, ErrorReject.CONTENT_TYPE);
								}

								if (ErrorReject.DESCRIPTION == null) {
									pstmt_tDBOutput_1.setNull(16, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(16, ErrorReject.DESCRIPTION);
								}

								if (ErrorReject.FILE_CLASSIFICATION == null) {
									pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(17, ErrorReject.FILE_CLASSIFICATION);
								}

								if (ErrorReject.FILE_ID == null) {
									pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(18, ErrorReject.FILE_ID);
								}

								if (ErrorReject.FILE_NAME == null) {
									pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(19, ErrorReject.FILE_NAME);
								}

								if (ErrorReject.OWNER == null) {
									pstmt_tDBOutput_1.setNull(20, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(20, ErrorReject.OWNER);
								}

								if (ErrorReject.REFERENCE == null) {
									pstmt_tDBOutput_1.setNull(21, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(21, ErrorReject.REFERENCE);
								}

								if (ErrorReject.ANN_VISIBILITY == null) {
									pstmt_tDBOutput_1.setNull(22, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(22, ErrorReject.ANN_VISIBILITY);
								}

								if (ErrorReject.CLAIM_ID == null) {
									pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_1.setString(23, ErrorReject.CLAIM_ID);
								}

								if (ErrorReject.dt_chargement != null) {
									pstmt_tDBOutput_1.setObject(24,
											new java.sql.Timestamp(ErrorReject.dt_chargement.getTime()),
											java.sql.Types.DATE);
								} else {
									pstmt_tDBOutput_1.setNull(24, java.sql.Types.DATE);
								}

								pstmt_tDBOutput_1.addBatch();
								nb_line_tDBOutput_1++;
								batchSizeCounter_tDBOutput_1++;
								if (batchSize_tDBOutput_1 > 0
										&& batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
									try {
										pstmt_tDBOutput_1.executeBatch();
									} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
										java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
												sqle_tDBOutput_1 = null;
										String errormessage_tDBOutput_1;
										if (ne_tDBOutput_1 != null) {
											// build new exception to provide the original cause
											sqle_tDBOutput_1 = new java.sql.SQLException(
													e_tDBOutput_1.getMessage() + "\ncaused by: "
															+ ne_tDBOutput_1.getMessage(),
													ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(),
													ne_tDBOutput_1);
											errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
										} else {
											errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
										}

										System.err.println(errormessage_tDBOutput_1);

									}
									tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
									insertedCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1 != -1
											? tmp_batchUpdateCount_tDBOutput_1
											: 0);
									rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1 != -1
											? tmp_batchUpdateCount_tDBOutput_1
											: 0);
									batchSizeCounter_tDBOutput_1 = 0;
								}
								commitCounter_tDBOutput_1++;
								if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
									if (batchSizeCounter_tDBOutput_1 > 0) {
										try {
											pstmt_tDBOutput_1.executeBatch();
										} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
											java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
													sqle_tDBOutput_1 = null;
											String errormessage_tDBOutput_1;
											if (ne_tDBOutput_1 != null) {
												// build new exception to provide the original cause
												sqle_tDBOutput_1 = new java.sql.SQLException(
														e_tDBOutput_1.getMessage() + "\ncaused by: "
																+ ne_tDBOutput_1.getMessage(),
														ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(),
														ne_tDBOutput_1);
												errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
											} else {
												errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
											}

											System.err.println(errormessage_tDBOutput_1);

										}
										tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();
										insertedCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1 != -1
												? tmp_batchUpdateCount_tDBOutput_1
												: 0);
										rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1 != -1
												? tmp_batchUpdateCount_tDBOutput_1
												: 0);
									}
									if (rowsToCommitCount_tDBOutput_1 != 0) {

									}
									conn_tDBOutput_1.commit();
									if (rowsToCommitCount_tDBOutput_1 != 0) {

										rowsToCommitCount_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1 = 0;
									batchSizeCounter_tDBOutput_1 = 0;
								}

								tos_count_tDBOutput_1++;

								/**
								 * [tDBOutput_1 main ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_1 process_data_end ] start
								 */

								currentComponent = "tDBOutput_1";

								/**
								 * [tDBOutput_1 process_data_end ] stop
								 */

							} // End of branch "ErrorReject"

// Start of branch "mst_annotation"
							if (mst_annotation != null) {

								/**
								 * [tDBOutput_2 main ] start
								 */

								currentComponent = "tDBOutput_2";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "mst_annotation"

									);
								}

								whetherReject_tDBOutput_2 = false;
								if (mst_annotation.id == null) {
									pstmt_tDBOutput_2.setNull(1, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(1, mst_annotation.id);
								}

								if (mst_annotation.change_time != null) {
									pstmt_tDBOutput_2.setObject(2,
											new java.sql.Timestamp(mst_annotation.change_time.getTime()),
											java.sql.Types.DATE);
								} else {
									pstmt_tDBOutput_2.setNull(2, java.sql.Types.DATE);
								}

								if (mst_annotation.CREATED_BY == null) {
									pstmt_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(3, mst_annotation.CREATED_BY);
								}

								if (mst_annotation.creation_time != null) {
									pstmt_tDBOutput_2.setObject(4,
											new java.sql.Timestamp(mst_annotation.creation_time.getTime()),
											java.sql.Types.DATE);
								} else {
									pstmt_tDBOutput_2.setNull(4, java.sql.Types.DATE);
								}

								if (mst_annotation.enabled == null) {
									pstmt_tDBOutput_2.setNull(5, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(5, mst_annotation.enabled);
								}

								if (mst_annotation.guid == null) {
									pstmt_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(6, mst_annotation.guid);
								}

								if (mst_annotation.last_updated_by == null) {
									pstmt_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(7, mst_annotation.last_updated_by);
								}

								if (mst_annotation.obj_version == null) {
									pstmt_tDBOutput_2.setNull(8, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(8, mst_annotation.obj_version);
								}

								if (mst_annotation.status == null) {
									pstmt_tDBOutput_2.setNull(9, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(9, mst_annotation.status);
								}

								if (mst_annotation.annotation_type == null) {
									pstmt_tDBOutput_2.setNull(10, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(10, mst_annotation.annotation_type);
								}

								if (mst_annotation.ref_claim == null) {
									pstmt_tDBOutput_2.setNull(11, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(11, mst_annotation.ref_claim);
								}

								if (mst_annotation.content_length == null) {
									pstmt_tDBOutput_2.setNull(12, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(12, mst_annotation.content_length);
								}

								if (mst_annotation.content_type == null) {
									pstmt_tDBOutput_2.setNull(13, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(13, mst_annotation.content_type);
								}

								if (mst_annotation.description == null) {
									pstmt_tDBOutput_2.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(14, mst_annotation.description);
								}

								if (mst_annotation.fileclassification == null) {
									pstmt_tDBOutput_2.setNull(15, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(15, mst_annotation.fileclassification);
								}

								if (mst_annotation.file_id == null) {
									pstmt_tDBOutput_2.setNull(16, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(16, mst_annotation.file_id);
								}

								if (mst_annotation.file_name == null) {
									pstmt_tDBOutput_2.setNull(17, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(17, mst_annotation.file_name);
								}

								if (mst_annotation.owner == null) {
									pstmt_tDBOutput_2.setNull(18, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(18, mst_annotation.owner);
								}

								if (mst_annotation.reference == null) {
									pstmt_tDBOutput_2.setNull(19, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(19, mst_annotation.reference);
								}

								if (mst_annotation.ann_visibility == null) {
									pstmt_tDBOutput_2.setNull(20, java.sql.Types.VARCHAR);
								} else {
									pstmt_tDBOutput_2.setString(20, mst_annotation.ann_visibility);
								}

								if (mst_annotation.claim_id == null) {
									pstmt_tDBOutput_2.setNull(21, java.sql.Types.INTEGER);
								} else {
									pstmt_tDBOutput_2.setLong(21, mst_annotation.claim_id);
								}

								if (mst_annotation.dt_chargement != null) {
									pstmt_tDBOutput_2.setObject(22,
											new java.sql.Timestamp(mst_annotation.dt_chargement.getTime()),
											java.sql.Types.DATE);
								} else {
									pstmt_tDBOutput_2.setNull(22, java.sql.Types.DATE);
								}

								pstmt_tDBOutput_2.addBatch();
								nb_line_tDBOutput_2++;
								batchSizeCounter_tDBOutput_2++;
								if (batchSize_tDBOutput_2 > 0
										&& batchSize_tDBOutput_2 <= batchSizeCounter_tDBOutput_2) {
									try {
										pstmt_tDBOutput_2.executeBatch();
									} catch (java.sql.BatchUpdateException e_tDBOutput_2) {
										globalMap.put("tDBOutput_2_ERROR_MESSAGE", e_tDBOutput_2.getMessage());
										java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),
												sqle_tDBOutput_2 = null;
										String errormessage_tDBOutput_2;
										if (ne_tDBOutput_2 != null) {
											// build new exception to provide the original cause
											sqle_tDBOutput_2 = new java.sql.SQLException(
													e_tDBOutput_2.getMessage() + "\ncaused by: "
															+ ne_tDBOutput_2.getMessage(),
													ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(),
													ne_tDBOutput_2);
											errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
										} else {
											errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
										}

										System.err.println(errormessage_tDBOutput_2);

									}
									tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
									insertedCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2 != -1
											? tmp_batchUpdateCount_tDBOutput_2
											: 0);
									rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2 != -1
											? tmp_batchUpdateCount_tDBOutput_2
											: 0);
									batchSizeCounter_tDBOutput_2 = 0;
								}
								commitCounter_tDBOutput_2++;
								if (commitEvery_tDBOutput_2 <= commitCounter_tDBOutput_2) {
									if (batchSizeCounter_tDBOutput_2 > 0) {
										try {
											pstmt_tDBOutput_2.executeBatch();
										} catch (java.sql.BatchUpdateException e_tDBOutput_2) {
											globalMap.put("tDBOutput_2_ERROR_MESSAGE", e_tDBOutput_2.getMessage());
											java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),
													sqle_tDBOutput_2 = null;
											String errormessage_tDBOutput_2;
											if (ne_tDBOutput_2 != null) {
												// build new exception to provide the original cause
												sqle_tDBOutput_2 = new java.sql.SQLException(
														e_tDBOutput_2.getMessage() + "\ncaused by: "
																+ ne_tDBOutput_2.getMessage(),
														ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(),
														ne_tDBOutput_2);
												errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
											} else {
												errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
											}

											System.err.println(errormessage_tDBOutput_2);

										}
										tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();
										insertedCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2 != -1
												? tmp_batchUpdateCount_tDBOutput_2
												: 0);
										rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2 != -1
												? tmp_batchUpdateCount_tDBOutput_2
												: 0);
									}
									if (rowsToCommitCount_tDBOutput_2 != 0) {

									}
									conn_tDBOutput_2.commit();
									if (rowsToCommitCount_tDBOutput_2 != 0) {

										rowsToCommitCount_tDBOutput_2 = 0;
									}
									commitCounter_tDBOutput_2 = 0;
									batchSizeCounter_tDBOutput_2 = 0;
								}

								tos_count_tDBOutput_2++;

								/**
								 * [tDBOutput_2 main ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_begin ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_begin ] stop
								 */

								/**
								 * [tDBOutput_2 process_data_end ] start
								 */

								currentComponent = "tDBOutput_2";

								/**
								 * [tDBOutput_2 process_data_end ] stop
								 */

							} // End of branch "mst_annotation"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "row1"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) ("C:/Users/Yassine Bahaj/Desktop/pfa/Files_CSV_200723/ods_annotation.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "row1");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				if (batchSizeCounter_tDBOutput_1 > 0) {
					try {
						if (pstmt_tDBOutput_1 != null) {

							pstmt_tDBOutput_1.executeBatch();

						}
					} catch (java.sql.BatchUpdateException e_tDBOutput_1) {
						globalMap.put("tDBOutput_1_ERROR_MESSAGE", e_tDBOutput_1.getMessage());
						java.sql.SQLException ne_tDBOutput_1 = e_tDBOutput_1.getNextException(),
								sqle_tDBOutput_1 = null;
						String errormessage_tDBOutput_1;
						if (ne_tDBOutput_1 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_1 = new java.sql.SQLException(
									e_tDBOutput_1.getMessage() + "\ncaused by: " + ne_tDBOutput_1.getMessage(),
									ne_tDBOutput_1.getSQLState(), ne_tDBOutput_1.getErrorCode(), ne_tDBOutput_1);
							errormessage_tDBOutput_1 = sqle_tDBOutput_1.getMessage();
						} else {
							errormessage_tDBOutput_1 = e_tDBOutput_1.getMessage();
						}

						System.err.println(errormessage_tDBOutput_1);

					}
					if (pstmt_tDBOutput_1 != null) {
						tmp_batchUpdateCount_tDBOutput_1 = pstmt_tDBOutput_1.getUpdateCount();

						insertedCount_tDBOutput_1

								+= (tmp_batchUpdateCount_tDBOutput_1 != -1 ? tmp_batchUpdateCount_tDBOutput_1 : 0);
						rowsToCommitCount_tDBOutput_1 += (tmp_batchUpdateCount_tDBOutput_1 != -1
								? tmp_batchUpdateCount_tDBOutput_1
								: 0);
					}
				}
				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

				}
				conn_tDBOutput_1.commit();
				if (commitCounter_tDBOutput_1 > 0 && rowsToCommitCount_tDBOutput_1 != 0) {

					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;

				conn_tDBOutput_1.close();

				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "ErrorReject");
				}

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tDBOutput_2 end ] start
				 */

				currentComponent = "tDBOutput_2";

				if (batchSizeCounter_tDBOutput_2 > 0) {
					try {
						if (pstmt_tDBOutput_2 != null) {

							pstmt_tDBOutput_2.executeBatch();

						}
					} catch (java.sql.BatchUpdateException e_tDBOutput_2) {
						globalMap.put("tDBOutput_2_ERROR_MESSAGE", e_tDBOutput_2.getMessage());
						java.sql.SQLException ne_tDBOutput_2 = e_tDBOutput_2.getNextException(),
								sqle_tDBOutput_2 = null;
						String errormessage_tDBOutput_2;
						if (ne_tDBOutput_2 != null) {
							// build new exception to provide the original cause
							sqle_tDBOutput_2 = new java.sql.SQLException(
									e_tDBOutput_2.getMessage() + "\ncaused by: " + ne_tDBOutput_2.getMessage(),
									ne_tDBOutput_2.getSQLState(), ne_tDBOutput_2.getErrorCode(), ne_tDBOutput_2);
							errormessage_tDBOutput_2 = sqle_tDBOutput_2.getMessage();
						} else {
							errormessage_tDBOutput_2 = e_tDBOutput_2.getMessage();
						}

						System.err.println(errormessage_tDBOutput_2);

					}
					if (pstmt_tDBOutput_2 != null) {
						tmp_batchUpdateCount_tDBOutput_2 = pstmt_tDBOutput_2.getUpdateCount();

						insertedCount_tDBOutput_2

								+= (tmp_batchUpdateCount_tDBOutput_2 != -1 ? tmp_batchUpdateCount_tDBOutput_2 : 0);
						rowsToCommitCount_tDBOutput_2 += (tmp_batchUpdateCount_tDBOutput_2 != -1
								? tmp_batchUpdateCount_tDBOutput_2
								: 0);
					}
				}
				if (pstmt_tDBOutput_2 != null) {

					pstmt_tDBOutput_2.close();
					resourceMap.remove("pstmt_tDBOutput_2");

				}
				resourceMap.put("statementClosed_tDBOutput_2", true);
				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

				}
				conn_tDBOutput_2.commit();
				if (commitCounter_tDBOutput_2 > 0 && rowsToCommitCount_tDBOutput_2 != 0) {

					rowsToCommitCount_tDBOutput_2 = 0;
				}
				commitCounter_tDBOutput_2 = 0;

				conn_tDBOutput_2.close();

				resourceMap.put("finish_tDBOutput_2", true);

				nb_line_deleted_tDBOutput_2 = nb_line_deleted_tDBOutput_2 + deletedCount_tDBOutput_2;
				nb_line_update_tDBOutput_2 = nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
				nb_line_inserted_tDBOutput_2 = nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
				nb_line_rejected_tDBOutput_2 = nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;

				globalMap.put("tDBOutput_2_NB_LINE", nb_line_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_UPDATED", nb_line_update_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_DELETED", nb_line_deleted_tDBOutput_2);
				globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "mst_annotation");
				}

				ok_Hash.put("tDBOutput_2", true);
				end_Hash.put("tDBOutput_2", System.currentTimeMillis());

				/**
				 * [tDBOutput_2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								ctn_tDBOutput_1.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tDBOutput_2 finally ] start
				 */

				currentComponent = "tDBOutput_2";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
						if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_2")) != null) {
							pstmtToClose_tDBOutput_2.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_2") == null) {
						java.sql.Connection ctn_tDBOutput_2 = null;
						if ((ctn_tDBOutput_2 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_2")) != null) {
							try {
								ctn_tDBOutput_2.close();
							} catch (java.sql.SQLException sqlEx_tDBOutput_2) {
								String errorMessage_tDBOutput_2 = "failed to close the connection in tDBOutput_2 :"
										+ sqlEx_tDBOutput_2.getMessage();
								System.err.println(errorMessage_tDBOutput_2);
							}
						}
					}
				}

				/**
				 * [tDBOutput_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final mst_annotation mst_annotationClass = new mst_annotation();

		int exitCode = mst_annotationClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = mst_annotation.class.getClassLoader()
					.getResourceAsStream("local_project/mst_annotation_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = mst_annotation.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
					context.setContextType("mst_annotation_Header", "id_Integer");
					if (context.getStringValue("mst_annotation_Header") == null) {
						context.mst_annotation_Header = null;
					} else {
						try {
							context.mst_annotation_Header = routines.system.ParserUtils
									.parseTo_Integer(context.getProperty("mst_annotation_Header"));
						} catch (NumberFormatException e) {
							System.err.println(String.format("Null value will be used for context parameter %s: %s",
									"mst_annotation_Header", e.getMessage()));
							context.mst_annotation_Header = null;
						}
					}
					context.setContextType("mst_annotation_Encoding", "id_String");
					if (context.getStringValue("mst_annotation_Encoding") == null) {
						context.mst_annotation_Encoding = null;
					} else {
						context.mst_annotation_Encoding = (String) context.getProperty("mst_annotation_Encoding");
					}
					context.setContextType("mst_annotation_RowSeparator", "id_String");
					if (context.getStringValue("mst_annotation_RowSeparator") == null) {
						context.mst_annotation_RowSeparator = null;
					} else {
						context.mst_annotation_RowSeparator = (String) context
								.getProperty("mst_annotation_RowSeparator");
					}
					context.setContextType("mst_annotation_File", "id_File");
					if (context.getStringValue("mst_annotation_File") == null) {
						context.mst_annotation_File = null;
					} else {
						context.mst_annotation_File = (String) context.getProperty("mst_annotation_File");
					}
					context.setContextType("mst_annotation_FieldSeparator", "id_String");
					if (context.getStringValue("mst_annotation_FieldSeparator") == null) {
						context.mst_annotation_FieldSeparator = null;
					} else {
						context.mst_annotation_FieldSeparator = (String) context
								.getProperty("mst_annotation_FieldSeparator");
					}
					context.setContextType("annotation_Server", "id_String");
					if (context.getStringValue("annotation_Server") == null) {
						context.annotation_Server = null;
					} else {
						context.annotation_Server = (String) context.getProperty("annotation_Server");
					}
					context.setContextType("annotation_Password", "id_Password");
					if (context.getStringValue("annotation_Password") == null) {
						context.annotation_Password = null;
					} else {
						String pwd_annotation_Password_value = context.getProperty("annotation_Password");
						context.annotation_Password = null;
						if (pwd_annotation_Password_value != null) {
							if (context_param.containsKey("annotation_Password")) {// no need to decrypt if it come from
																					// program argument or parent job
																					// runtime
								context.annotation_Password = pwd_annotation_Password_value;
							} else if (!pwd_annotation_Password_value.isEmpty()) {
								try {
									context.annotation_Password = routines.system.PasswordEncryptUtil
											.decryptPassword(pwd_annotation_Password_value);
									context.put("annotation_Password", context.annotation_Password);
								} catch (java.lang.RuntimeException e) {
									// do nothing
								}
							}
						}
					}
					context.setContextType("annotation_Sid", "id_String");
					if (context.getStringValue("annotation_Sid") == null) {
						context.annotation_Sid = null;
					} else {
						context.annotation_Sid = (String) context.getProperty("annotation_Sid");
					}
					context.setContextType("annotation_Port", "id_String");
					if (context.getStringValue("annotation_Port") == null) {
						context.annotation_Port = null;
					} else {
						context.annotation_Port = (String) context.getProperty("annotation_Port");
					}
					context.setContextType("annotation_Schema", "id_String");
					if (context.getStringValue("annotation_Schema") == null) {
						context.annotation_Schema = null;
					} else {
						context.annotation_Schema = (String) context.getProperty("annotation_Schema");
					}
					context.setContextType("annotation_Login", "id_String");
					if (context.getStringValue("annotation_Login") == null) {
						context.annotation_Login = null;
					} else {
						context.annotation_Login = (String) context.getProperty("annotation_Login");
					}
					context.setContextType("annotation_AdditionalParams", "id_String");
					if (context.getStringValue("annotation_AdditionalParams") == null) {
						context.annotation_AdditionalParams = null;
					} else {
						context.annotation_AdditionalParams = (String) context
								.getProperty("annotation_AdditionalParams");
					}
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
			if (parentContextMap.containsKey("mst_annotation_Header")) {
				context.mst_annotation_Header = (Integer) parentContextMap.get("mst_annotation_Header");
			}
			if (parentContextMap.containsKey("mst_annotation_Encoding")) {
				context.mst_annotation_Encoding = (String) parentContextMap.get("mst_annotation_Encoding");
			}
			if (parentContextMap.containsKey("mst_annotation_RowSeparator")) {
				context.mst_annotation_RowSeparator = (String) parentContextMap.get("mst_annotation_RowSeparator");
			}
			if (parentContextMap.containsKey("mst_annotation_File")) {
				context.mst_annotation_File = (String) parentContextMap.get("mst_annotation_File");
			}
			if (parentContextMap.containsKey("mst_annotation_FieldSeparator")) {
				context.mst_annotation_FieldSeparator = (String) parentContextMap.get("mst_annotation_FieldSeparator");
			}
			if (parentContextMap.containsKey("annotation_Server")) {
				context.annotation_Server = (String) parentContextMap.get("annotation_Server");
			}
			if (parentContextMap.containsKey("annotation_Password")) {
				context.annotation_Password = (java.lang.String) parentContextMap.get("annotation_Password");
			}
			if (parentContextMap.containsKey("annotation_Sid")) {
				context.annotation_Sid = (String) parentContextMap.get("annotation_Sid");
			}
			if (parentContextMap.containsKey("annotation_Port")) {
				context.annotation_Port = (String) parentContextMap.get("annotation_Port");
			}
			if (parentContextMap.containsKey("annotation_Schema")) {
				context.annotation_Schema = (String) parentContextMap.get("annotation_Schema");
			}
			if (parentContextMap.containsKey("annotation_Login")) {
				context.annotation_Login = (String) parentContextMap.get("annotation_Login");
			}
			if (parentContextMap.containsKey("annotation_AdditionalParams")) {
				context.annotation_AdditionalParams = (String) parentContextMap.get("annotation_AdditionalParams");
			}
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		parametersToEncrypt.add("annotation_Password");
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_2Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_2) {
			globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_2.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : mst_annotation");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 133182 characters generated by Talend Open Studio for Data Integration on the
 * 31 juillet 2023 à 12:25:31 WEST
 ************************************************************************************************/